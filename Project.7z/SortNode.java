/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Emilio Singh u14006512
 * 
 * The SortNode class is a class that contains an individual and an associated fitness value.
 * It was used to facilitate an easier sorting process of individuals by fitness value.
 */
public class SortNode {
   
    private Individual indie;
    private double fitness;
    
    /**Default Constructor
     */
    SortNode()
    {
        
    }
    /**
     * A getter method to retrieve the stored individual in the SortNode
     * @return  indie
     * The individual in question stored within the SortNode
     */
    public Individual getIndie() {
        return indie;
    }

    /**
     * A getter method to retrieve the stored fitness in the SortNode
     * @return  fitness
     * The fitness value in question stored within the SortNode
     */
    public double getFitness() {
        return fitness;
    }
    
    
    /**A constructor provided to enable SortNodes to be made with given fitness,
     * and individual values for its variables
     */
    SortNode(Individual i, double fit)
    {
        indie=i;
        fitness=fit;
    }
}
