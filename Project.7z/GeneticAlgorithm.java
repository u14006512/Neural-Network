/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Emilio Singh
 * 
 * The GeneticAlgorithm class encapsulates all of the other functionality 
 * described in these source files. All of the major aspects of the program
 * are realised here in the evolveSolution() function which makes use
 * of nearly every other class specified here either directly or indirectly.
 * 
 * The goal of the GA is to evolve some initially random collection of images
 * into some image that resembles another. This is served by sampling images
 * from a large directory and the Genetic Algorithm itself receives parameters
 * that are given to it via the interface, or mosaic class.
 * 
 * Once properly configured, the algorithm will attempt to solve the problem
 * as best as it can. Unfortunately, a major concern with this program is the
 * speed, cost and efficiency of it. The fitness function is extremely expensive
 * in comparison to the other functions and while care has been taken to minimise 
 * its calling, it is still used with some frequency. The issue at hand is still 
 * somewhat simple enough to be within the domain of reasonable to solve for a GA.
 * 
 * The default parameters used here were chosen based on limited experimentation
 * with the performance of the GA itself under various conditions. Possibly, given
 * sufficient computing power, time and more finely tuned parameters, the GA would
 * perform significantly more optimally than it does now.
 */
public class GeneticAlgorithm {

    Population gaPop;

    SelectionOperators selection;
    MutationOperators mutation;

    static int generations = 0;
    static String targetName;

    
    /**A getter to return the current generation of the population
     * @return 
     * Returns the current generation of the population
     */
    public static int getGenerations() {
        return generations;
    }

    /**A setter to set the value of the generations variable 
     * @param generations 
     * The new generation value to update the generation variable with.
    */
    public static void setGenerations(int generations) {
        GeneticAlgorithm.generations = generations;
    }
    double mutationProb = 0.5;
    double crossProb = 0.5;
    static double crossPx = 0.5;
    int selectionType = 1;
    int crossoverType = 1;
    int mutType = 1;

    int tournamentSize = 5;

    /**A getter to return the name of the target image to be produced
     * @return 
     * Returns the name of the target image as specified by the user
     */
    public static String getTargetName() {
        return targetName;
    }

    /**A getter to return the crossover probability
     * @return 
     * Returns the crossover probability;
     */
    public static double getCrossPX() {
        return crossPx;
    }

    
    /**
     * Default Constructor
     */
    GeneticAlgorithm() {

    }

    /**Constructor that stores the target image name
     */
    GeneticAlgorithm(String targ) {
        targetName = targ;
        gaPop = new Population(20, 3, 3);
        tournamentSize = 5;
    }

    /**
     * Utility constructor that sets up genetic algorithm according to
     * user specified input parameters.
     * 
     * @param coPrX 
     * The probability of an individual cell being used during crossover
     * 
     * @param coProb  
     * The probability that two individuals will perform crossover
     * 
     * @param coT
     * The type of crossover operator to be used
     * 
     * @param cols  
     * The number of columns in the target image
     * 
     * @param initPop  
     * The initial population used by the genetic algorithm
     * 
     * @param m 
     * The type of mutation to be used
     * 
     * @param mutProb 
     * The probability that a given individual will mutate
     * 
     * @param rows 
     * The number of rows in the target image
     * 
     * @param selT 
     * The type of selection operator used
     * 
     * @param tSize 
     * The size of tournaments for tournament selection
     * 
     * @param target 
     * The name to be used to generate the target image.
     */
    GeneticAlgorithm(int initPop, double mutProb, double coProb, double coPrX, int selT, int coT, int tSize, String target, int rows, int cols, int m) {
        targetName = target;
        gaPop = new Population(initPop, rows, cols);
        mutationProb = mutProb;
        crossProb = coProb;
        selectionType = selT;
        crossoverType = coT;
        tournamentSize = tSize;
        crossPx = coPrX;
        mutType = m;
    }
    /**A getter to retrieve the current population
     * 
     * @return 
     * The population variable that stores the current population
     */
    public Population getGaPop() {
        return gaPop;
    }

    /**
     * This is one of the convergence conditions used to halt the evolution process
     * (GA evolveSolution()) function.
     * 
    *This method traverses through all of the population members and sees if any
    * of the members have a fitness higher than a specified value, 95, in this case
    * as my fitness values are transformed to be values from 0 to 100 with 0 being a
    * totally different image to the target image * and 100 being the target image 
    * matched perfectly. If such an individual exists, there is little point in
    * continuing to evolve the last few pixels and so we halt the evolution process.
    * 
    * @return 
    * A boolean value if an individual was found with a fitness greater than 95
    * @param fitnessValues 
    * A list of fitness values with associated individuals to determine the current
    * best individual in the population.
    */
    public boolean optimalFitnessFound(ArrayList<Individual> fitnessValues) {
        double bestFit = fitnessValues.get(0).getFitnessScore();

        for (int i = 0; i < fitnessValues.size(); i++) {
            if (fitnessValues.get(i).getFitnessScore() > bestFit) {
                bestFit = fitnessValues.get(i).getFitnessScore();
            }
        }

        if (bestFit >95) {
            return true;
        }

        return false;
    }

    /**
     *  This is one of the convergence conditions used to halt the evolution process
     * (GA evolveSolution()) function.
     * 
    *This method traverses through all of the population and determines the
    * average fitness of all members in the current population. It then calculates
    * the standard deviation of this fitness measure and then counts the number
    * of individuals of the population that are currently within: 
    * (mean-1 standard deviation,mean+ 1 standard deviation).
    * 
    * If the number of individuals within the range is greater than the number
    * of individuals outside of the range and the average fitness of all members
    * of the population is 80, then we can presume that by and large, most of
    * the population has reached a stable point in their traversal of the search
    * space and are not likely to dramatically increase their fitness over
    * future generations. Rather, if it is the case that these conditions are
    * true, then on average, an individual in the population is very close
    * to the target image and a majority of the population is close to this
    * theoretical average individual meaning that, in theory, our individuals
    * have converged on some point in the search space.
    *
    * This means we can stop the search process.
    * 
    * @return 
    * A boolean value if the population appears to be stable and non-progressing(stagnant)
    * @param fitnessValues 
    * A list of fitness values with associated individuals to determine the current
    * best individual in the population.
    */
    public boolean stabilityReached(ArrayList<Individual> fitnessValues) {
        double averageFitness = 0;
        double totalFitness = 0;
        double stdDevFitness = 0;

        for (int i = 0; i < fitnessValues.size(); i++) {
            totalFitness = totalFitness + fitnessValues.get(i).getFitnessScore();
        }

        averageFitness = totalFitness / fitnessValues.size();

        for (int i = 0; i < fitnessValues.size(); i++) {
            stdDevFitness = stdDevFitness + Math.pow((fitnessValues.get(i).getFitnessScore() - averageFitness), 2);
        }

        stdDevFitness = stdDevFitness / fitnessValues.size();
        stdDevFitness = Math.sqrt(stdDevFitness);

        double lowerBound = averageFitness - stdDevFitness;
        double higherBound = averageFitness + stdDevFitness;
        int numWithinRange = 0, numOutOfRange = 0;
        for (int i = 0; i < fitnessValues.size(); i++) {
            if (fitnessValues.get(i).getFitnessScore() >= lowerBound && fitnessValues.get(i).getFitnessScore() <= higherBound) {
                numWithinRange++;
            } else {
                numOutOfRange++;
            }
        }

        if (numWithinRange > numOutOfRange && averageFitness > 80) {
            return true;
        }
        return false;
    }

    /**
     * This method is essentially the very heart of the Genetic Algorithm.
     * It contains Selection,Crossover and Mutation operations that will take
     * an initially randomly, but valid, generated population and evolve them
     * through the process below until convergence is reached:
     * 
     * 1) Initialise the starting population
     * 2) Make use of a selection operator to select members of the population
     * 3) Determine if those selected individuals will crossover and produce
     *    offspring
     * 4) If offspring were produced, have them now mutate
     * 5) Pick the best children and best parents, (50;50 split) to form the
     *    new generation
     * 
     * Repeat 2-5 until convergence is reached.
     * 
     * It makes use of 3 convergence conditions to gauge the worth of the population
     * Conditions 2 and 3 are explained in further detail in their respective functions.
     * 
     * 1) Generations &gt Max GenerationLimit
     *    -We want to limit the cost of the GA such that it does not spend excessive
     *     amounts of time trying to refine what amounts to a few pixels to a target image.
     *     Hence, we have a maximum capacity on the number of generations to ensure that the
     *     GA stops after a certain amount of time. In our case, our max limit is set
     *     at 5 times the size of the population to allow for sufficient exploration and 
     *     exploitation without being too costly or time-heavy.
     * 2) populationStability ==true
     * 3) optimal Individual found==true
     * 
     * If any of the three are true, then we halt the evolution process and select
     * the best individual from the population and then send it to be converted
     * to an actual jpg image.
     * 
     */
    public void evolveSolution() throws IOException {
        ArrayList<Individual> fitnessList = new ArrayList<>();

        ArrayList<Individual> testPopSelected = new ArrayList<>();
        ArrayList<Individual> offspringList = new ArrayList<>();
        ArrayList<Individual> tempPopulationHoldingList = new ArrayList<>();
        ArrayList<SortNode> newGeneration = new ArrayList<>();

        gaPop.generateInitialPopulation();
        System.out.println("Population Generated!");
        setGenerations(0);

        for (int i = 0; i < getGaPop().size; i++) {
            fitnessList.add(new Individual(ImageManipulation.rows,ImageManipulation.cols,gaPop.getMember(i).chromosome));
            gaPop.getMember(i).setFitnessScore(fitnessFunction.getFitness(gaPop.getMember(i)));
            fitnessList.get(i).setFitnessScore(gaPop.getMember(i).getFitnessScore());
            System.out.println(" ");
            System.out.println("=============================");
            System.out.println("Fitness Calculated for " + i + " member of population " + fitnessList.get(i).getFitnessScore());
            System.out.println("=============================");
            System.out.println(" ");
        }
        
        //        
        while (getGenerations()<5*getGaPop().size && stabilityReached(fitnessList)==false && optimalFitnessFound(fitnessList)==false) {
        
            System.out.println(" ");
            System.out.println("=============================");
            System.out.println("Current Generation "+ GeneticAlgorithm.getGenerations());
            System.out.println("=============================");
            System.out.println(" ");
            
            setGenerations(getGenerations() + 1);
            
            if (testPopSelected.size() > 0) {
                testPopSelected.clear();
            }
            if (offspringList.size() > 0) {
                offspringList.clear();
            }
            if (tempPopulationHoldingList.size() > 0) {
                tempPopulationHoldingList.clear();
            }

            switch (selectionType) {

                case 1:
                    testPopSelected.addAll(SelectionOperators.tournamentSelectIndividuals(tournamentSize, getGaPop()));
                    break;
                case 2:
                    testPopSelected.addAll(SelectionOperators.rouletteWheelSelectIndividuals(getGaPop()));
                    break;
            }

            System.out.println(" ");
            System.out.println("=============================");
            System.out.println("Selection Completed");
            System.out.println("=============================");
            System.out.println(" ");
            
            for (int i = 1; i < testPopSelected.size(); i = i + 2) {
                offspringList.addAll(CrossOverOperators.crossOver(crossProb, testPopSelected.get(i - 1), testPopSelected.get(i), crossoverType));
            }

            System.out.println(" ");
            System.out.println("=============================");
            System.out.println("Cross Over Completed");
            System.out.println("=============================");
            System.out.println(" ");
            
            Random chance = new Random(System.nanoTime());
            double mutProb;
            Individual[] offList = null;
            if (offspringList.size() > 0) {
                offList = new Individual[offspringList.size()];

                for (int i = 0; i < offspringList.size(); i++) {
                    offList[i] = offspringList.get(i);
                }

                for (int i = 0; i < offList.length; i++) {
                    mutProb = chance.nextDouble();

                    if (mutProb <= mutationProb) {

                        offList[i] = MutationOperators.mutateIndividual(offList[i], mutType);
                    }
                }

                offspringList.clear();
                for (int i = 0; i < offList.length; i++) {
                    offspringList.add(offList[i]);
                }

                for (int i = 0; i < offspringList.size(); i++) {
                    newGeneration.add(new SortNode(offspringList.get(i), fitnessFunction.getFitness(offspringList.get(i))));
                }

            }
            
            System.out.println(" ");
            System.out.println("=============================");
            System.out.println("Mutation Completed");
            System.out.println("=============================");
            System.out.println(" ");
            SortNode[] sortedListByFitness;
            if (offspringList.size() > 0) {
                sortedListByFitness = new SortNode[getGaPop().size + offspringList.size()];
            } else {
                sortedListByFitness = new SortNode[getGaPop().size];
            }
            for (int u = 0; u < gaPop.size; u++) {
                sortedListByFitness[u] = new SortNode(gaPop.getMember(u), gaPop.getMember(u).getFitnessScore());
            }

            if (offspringList.size() > 0) {
                int w=0;
                for (int i = getGaPop().size; i < getGaPop().size + offspringList.size(); i++) {
                    sortedListByFitness[i] = (new SortNode(offspringList.get(w),offspringList.get(w).getFitnessScore()));
                    w++;
                }
            }

            int i, j, first;
            SortNode temp;
            for (i = sortedListByFitness.length - 1; i > 0; i--) {
                first = 0;
                for (j = 1; j <= i; j++) {
                    if (sortedListByFitness[j].getFitness() < sortedListByFitness[first].getFitness()) {
                        first = j;
                    }
                }
                temp = sortedListByFitness[first];
                sortedListByFitness[first] = sortedListByFitness[i];
                sortedListByFitness[i] = temp;
            }
            fitnessList.clear();

            for (int s = 0; s < getGaPop().size; s++) {
                newGeneration.add(sortedListByFitness[s]);
            }

            this.gaPop.callExtinction();
            ArrayList<Individual> feedIn = new ArrayList<>();

            for (int u = 0; u < newGeneration.size(); u++) {
                feedIn.add(newGeneration.get(i).getIndie());
            }
            newGeneration.clear();
            gaPop.addMembersToPopulation(feedIn);

            for (int t = 0; t < getGaPop().size; t++) {
                fitnessList.add(gaPop.getMember(t));
                fitnessList.get(t).setFitnessScore(fitnessFunction.getFitness(fitnessList.get(i)));
            }

        }
        double bestFit = fitnessList.get(0).getFitnessScore();
        int index = 0;

        for (int i = 0; i < gaPop.size; i++) {
            if (fitnessList.get(i).getFitnessScore()> bestFit) {
                index = i;
                bestFit = fitnessList.get(i).getFitnessScore();
            }
        }

        ImageManipulation.generateFinalImage(gaPop.getMember(index));

    }
}
