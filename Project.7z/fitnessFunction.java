/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 *
 * @author Emilio Singh u14006512
 */
public class fitnessFunction {

    fitnessFunction() {

    }

    public static double getFitness(Individual indie) throws IOException {
        return getFitnessChromosome(indie.getChromosome());
    }

    public static double getFitnessChromosome(int[][] matrix) throws IOException {
        double fitness = 0;

        // For each cell in the matrix
        for (int row = 0; row < ImageManipulation.getRows(); row++) {
            for (int col = 0; col < ImageManipulation.getCols(); col++) {
                int cellIndex = matrix[row][col];
                // Get the fitness of that cell
                fitness += getCellFitness(cellIndex, row, col);
            }
        }

        // Return the average fitness (from 0 - 100)
        fitness = fitness/(double) (matrix.length * matrix[0].length);

        return fitness;
    }

    private static double getCellFitness(int cella, int rowValue, int colValue) throws IOException {
        BufferedImage real = ImageManipulation.getImage(ImageManipulation.getSrcImageIndex());

        BufferedImage cell = ImageManipulation.getImage(cella);

        

        int width = cell.getWidth(), height = cell.getHeight();
        // Alpha, Red, Blue and Green values for Cell, Real and Final
        double ac = 0, rc = 0, bc = 0, gc = 0,
                ar = 0, rr = 0, br = 0, gr = 0,
                af = 0, rf = 0, bf = 0, gf = 0;

        double aContrib, rContrib, bContrib, gContrib;

        int[] cellRGB = cell.getRGB(0, 0, width, height, null, 0, cell.getWidth());
        int[] realRGB = real.getRGB(((colValue * width)), ((rowValue * height)), width, height, null, 0, cell.getWidth());
        int cellTotal = 0, realTotal = 0;

        for (int i = 0; i < cellRGB.length; i++) {
            cellTotal += cellRGB[i];
            realTotal += realRGB[i];
        }
        
        cellTotal /= cellRGB.length;
        realTotal /= cellRGB.length;
        
        Color cellCol = new Color(cellTotal, true);
        Color realCol = new Color(realTotal, true);
        
        ac = cellCol.getAlpha();
        rc = cellCol.getRed();
        bc = cellCol.getBlue();
        gc = cellCol.getGreen();
        
        ar = realCol.getAlpha();
        rr = realCol.getRed();
        br = realCol.getBlue();
        gr = realCol.getGreen();

        // is this necessary? I dont think it is
        /*
        ac /= (double)totalPixels;
        rc /= (double)totalPixels;
        gc /= (double)totalPixels;
        bc /= (double)totalPixels;

        ar /= (double)totalPixels;
        rr /= (double)totalPixels;
        gr /= (double)totalPixels;
        br /= (double)totalPixels;
         */
        // Get the difference between cell and real values
        af = 1.0-(Math.abs(ac - ar) / 255.0);
        rf = 1.0-(Math.abs(rc - rr) / 255.0);
        bf =1.0- (Math.abs(bc - br) / 255.0);
        gf = 1.0-(Math.abs(gc - gr) / 255.0);

        // Get percentage of contribution of arbg
        double totalR = ar + rr + br + gr;
        aContrib = ar / totalR * 100.0;
        rContrib = rr / totalR * 100.0;
        bContrib = br / totalR * 100.0;
        gContrib = gr / totalR * 100.0;

        // Return the fitness of the cell (from 0 - 100)
        return (af * aContrib) + (rf * rContrib) + (bf * bContrib) + (gf + gContrib);
    }

}
