/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Emilio Singh u14006512
 * 
 * The population class exists to encapsulate the population within the search space
 * into one container that provides methods to generate members and control the membership 
 * to the population as well as provide methods to help manage it.
 * 
 * Population contains an array list which will store the actual individuals as well 
 * as row and column values used to create each individual. Finally, it provides a number
 * of methods that deal primarily with managing the size and members of the population.
 */
public class Population {

    int size = 5;
    ArrayList<Individual> gaPop;
    static int rows;
    static int cols;

    /**
    * Getter function for individuals in population
    * @return gaPop[i]
    * The individual stored in the population at i
    * 
    * @param i
    * The index to retrieve the population member from.
    */
    public Individual getMember(int i) {
        return gaPop.get(i);
    }

    /**
    * Getter function for population list
    * @return gaPop
    * The population stored within the class
    */
    public ArrayList<Individual> getGaPop() {
        return gaPop;
    }
    /**
     * Default Constructor
     */
    Population() {

    }
    
    /**
     * Constructor method to initialise a population's member's characteristics as
     * well as the size
     */
    Population(int si, int a, int b) {
        size = si;
        gaPop = new ArrayList<>();
        rows = a;
        cols = b;

    }

    /**
     * Getter function for row value
     *
     * @return rows 
     * The row value stored for population members
     */
    static public int getRows() {
        return rows;
    }

    /**
     * Getter function for column value
     *
     * @return cols 
     * The column value stored for population members
     */
    static public int getCols() {
        return cols;
    }

    /**
     * Constructor used to instantiate a population with a fixed size for its
     * members in terms of rows and columns.
     */
    Population(int a, int b) {
        gaPop = new ArrayList<>();
        rows = a;
        cols = b;
    }

    /**
     * This method will generate an initially random population for the GA to
     * work with.
     *
     * Initial members are generated randomly and then validated according to
     * rules before being finally allowed into the final population.
     */
    public void generateInitialPopulation() throws IOException {
        int index1;
        int tmpCell;
        System.out.println(" ");
        System.out.println("================================================= ");
        for (int i = 0; i < size; i++) {
            gaPop.add(new Individual(rows, cols));

            for (int j = 0; j < rows; j++) {
                for (int k = 0; k < cols; k++) {
                    index1 = ImageManipulation.genIndex();
                    if (index1 == ImageManipulation.srcImageIndex) {
                        index1 = ImageManipulation.genIndex();
                    }
                    tmpCell = index1;
                    gaPop.get(i).chromosome[j][k] = tmpCell;
                }

            }

            validateIndividual(gaPop.get(i));
            System.out.println("Generated Individudal: " + i);
        }

        System.out.println("================================================= ");
        System.out.println(" ");
    }

    /**
     * This method will take a specified individual and a specified
     * image/index/gene and calculate its frequency in the given chromosome. If
     * the frequency is >= 20% of the whole chromosome, it is rejected for being
     * used as it comprises too much of the given individual's chromosome.
     *
     * @param candidate The individual whose chromosome's diversity is being
     * tested.
     * @param candidateImageIndex The index that is to be searched for in the
     * chromosome for its frequency
     */
    private static boolean validateDiversity(Individual candidate, int candidateImageIndex) throws IOException {

        int freq = 0;

        for (int i = 0; i < candidate.rows; i++) {
            for (int j = 0; j < candidate.cols; j++) {
                if (candidate.chromosome[i][j] == candidateImageIndex) {
                    freq++;
                }
            }
        }

        double divScore = freq / candidate.cols * candidate.rows;

        if (divScore >= 0.2) {
            return false;
        } else {
            return true;
        }

    }

    /**
     * This method receives an individual and will validate it according to the
     * rules.
     *
     * Should an individual cell in the chromosome be found to be causing the
     * chromosome to be invalid, the cell location is replaced with a new
     * index/image/gene until the chromosome at that point is valid. This
     * process is repeated until the final validated chromosome is produced.
     * This method may potentially increase memory/computational overhead but a
     * sufficiently large image directory will greatly alleivate that problem.
     *
     * * A valid chromosome is one that has no cells that are adjacent to each
     * other that are the same.
     *
     * This produces 3 suites of cases for cell adjacency: 1) 4 Corner cases -
     * the cell in question has 3 surrounding cells 2) 4 General edge cases -
     * the cell in question has 6 surrounding cells 3) 1 General case - the cell
     * in question has 8 surrounding cells
     *
     * Each cell is checked for potential duplicates in the surrounding area.
     *
     * A well-formed chromosome is a valid chromosome that has a much diversity
     * as possible. To achieve this, a measure of allowing a single image, gene,
     * to be up to 20% of an individual's chromosome is implemented such that a
     * cell will not be declared valid if it contains images/genes where said
     * images/genes, are found in proportions greater than 20%
     *
     * @param candidate The target individual to be validated.
     */
    private void validateIndividual(Individual candidate) throws IOException {
        //CORNER CHECKS

        boolean foundDuplicate = false;
        int targetCheckImage;
        for (int j = 0; j < candidate.rows; j++) {
            for (int k = 0; k < candidate.cols; k++) {
                targetCheckImage = candidate.chromosome[j][k];

                do {
                    foundDuplicate = false;
                    if (j == 0 && k == 0) {

                        if (candidate.chromosome[j][k + 1] == targetCheckImage) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k] == targetCheckImage) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k + 1] == targetCheckImage) {
                            foundDuplicate = true;
                        }

                    } else if (j == 0 && k == cols - 1) {

                        if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }

                    } else if (j == rows - 1 && k == 0) {

                        if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }

                    } else if (j == rows - 1 && k == cols - 1) {

                        if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }
                    } else //General Edge Cases
                    {
                        if (j == 0 && k != 0 && k != cols - 1) {

                            if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j + 1][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            }

                        } else if (k == 0 && j != 0 && j != rows - 1) {

                            if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j + 1][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            }

                        } else if (k == cols - 1 && j != 0 && j != rows - 1) {

                            if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            }

                        } else if (j == rows - 1 && k != 0 && k != cols - 1) {

                            if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            }

                        } else //General Case
                        {
                            if (j - 1 >= 0 && k - 1 >= 0 && candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (j - 1 >= 0 && candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (j - 1 >= 0 && k + 1 < cols && candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (k - 1 >= 0 && candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (k + 1 < cols && candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (j + 1 < rows && k - 1 >= 0 && candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (j + 1 < rows && candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                                foundDuplicate = true;
                            } else if (j + 1 < rows && k + 1 < cols && candidate.chromosome[j + 1][k + 1] == (targetCheckImage)) {
                                foundDuplicate = true;
                            }
                        }
                    }

                    if (foundDuplicate == true) {
                        int indx;

                        boolean validEntry = false;
                        do {
                            indx = ImageManipulation.genIndex();

                            validEntry = validateDiversity(candidate, indx);
                            candidate.setGene(indx, j, k);
                            targetCheckImage = indx;
                        } while (validEntry == false);

                    }
                } while (foundDuplicate == true);

            }

        }

    }

    /**
     * A method to check cell validity. A valid chromosome is one that has no
     * cells that are adjacent to each other that are the same.
     *
     * This produces 3 suites of cases for cell adjacency: 1) 4 Corner cases -
     * the cell in question has 3 surrounding cells 2) 4 General edge cases -
     * the cell in question has 6 surrounding cells 3) 1 General case - the cell
     * in question has 8 surrounding cells
     *
     * Each cell is checked for potential duplicates in the surrounding area.
     *
     * A well-formed chromosome is a valid chromosome that has a much diversity
     * as possible. To achieve this, a measure of allowing a single image, gene,
     * to be up to 20% of an individual's chromosome is implemented such that a
     * cell will not be declared valid if it contains images/genes where said
     * images/genes, are found in proportions greater than 20%
     *
     * @return This returns a boolean value that indicates if the cell is
     * valid(well formed) or not
     *
     * @param candidate This is the specific individual whose chromosomal
     * validity must be checked.
     *
     */
    public static boolean checkValidity(Individual candidate) throws IOException {
        boolean foundDuplicate = false;
        int targetCheckImage = 0;
        for (int j = 0; j < candidate.rows; j++) {
            for (int k = 0; k < candidate.cols; k++) {
                targetCheckImage = candidate.chromosome[j][k];

                foundDuplicate = false;
                if (j == 0 && k == 0) {

                    if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j + 1][k + 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    }

                } else if (j == 0 && k == candidate.cols - 1) {

                    if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    }

                } else if (j == candidate.rows - 1 && k == 0) {

                    if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    }

                } else if (j == candidate.rows - 1 && k == candidate.cols - 1) {

                    if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    } else if (candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                        foundDuplicate = true;
                    }
                } else //General Edge Cases
                {
                    if (j == 0 && k != 0 && k != candidate.cols - 1) {

                        if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }

                    } else if (k == 0 && j != 0 && j != candidate.rows - 1) {

                        if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }

                    } else if (k == candidate.cols - 1 && j != 0 && j != candidate.rows - 1) {

                        if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }

                    } else if (j == candidate.rows - 1 && k != 0 && k != candidate.cols - 1) {

                        if (candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }

                    } else //General Case
                    {
                        if (j - 1 >= 0 && k - 1 >= 0 && candidate.chromosome[j - 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (j - 1 >= 0 && candidate.chromosome[j - 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (j - 1 >= 0 && k + 1 < candidate.cols && candidate.chromosome[j - 1][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (k - 1 >= 0 && candidate.chromosome[j][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (k + 1 < candidate.cols && candidate.chromosome[j][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (j + 1 < candidate.rows && k - 1 >= 0 && candidate.chromosome[j + 1][k - 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (j + 1 < candidate.rows && candidate.chromosome[j + 1][k] == (targetCheckImage)) {
                            foundDuplicate = true;
                        } else if (j + 1 < candidate.rows && k + 1 < candidate.cols && candidate.chromosome[j + 1][k + 1] == (targetCheckImage)) {
                            foundDuplicate = true;
                        }
                    }
                }

            }

        }

        /*
        Validity is only assured when no duplicates were found and the passed image is a 
        sufficiently small part of the total chromosome.
         */
        boolean validEntry = validateDiversity(candidate, targetCheckImage);
        if (foundDuplicate == false && validEntry == true) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * This method enables the adding of a specified list of individuals to be
     * added to the population list.
     *
     * @param newMembers A list of new members to add to the population
     */
    public void addMembersToPopulation(ArrayList<Individual> newMembers) {
        ArrayList<Individual> addList = new ArrayList<>();

        for (int i = 0; i < newMembers.size(); i++) {
            addList.add(newMembers.get(i));
        }
        while (addList.size() > 0) {
            gaPop.add(addList.remove(0));

        }
    }

    /**
     * This method is used to remove from the stored population, members as
     * specified by a passed list. It enables specific members of the population
     * to be removed as and when necessary.
     *
     * @param membersToDie A list of members of the population to be removed.
     */
    public void purgeMembersFromPopulation(ArrayList<Individual> membersToDie) {
        ArrayList<Individual> purgeList = new ArrayList<>();

        for (int i = 0; i < membersToDie.size(); i++) {
            purgeList.add(membersToDie.get(i));
        }

        int j = 0;
        while (purgeList.size() > 0) {

            for (int k = 0; k < gaPop.size(); k++) {
                if (gaPop.get(k) == (purgeList.get(j))) {
                    gaPop.remove(k);
                    purgeList.remove(j);
                    break;
                }
            }

        }
    }

    /**
     * callExtinction is an external method provided to enable the internally
     * stored population within this class to be destroyed, that is deleted,
     * upon request.It is primarily used to reset the stored population prior to
     * initialisation from the new generation.
     */
    public void callExtinction() {
        gaPop.clear();
    }
}
