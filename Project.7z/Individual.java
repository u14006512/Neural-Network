/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Emilio Singh u14006512
 * 
 * Individual is the class that represents individual members of the population.
 * 
 * It has a number of key components.
 * The first, fitnessScore is a double variable that is used to store the fitness
 * value that is associated with the specific individual. Since fitness values are expensive
 * to calculate, storing them makes for better computational efficiency than recalculating them
 * frequently.
 * 
 * The next aspect of this is the Chromosome. The chromosome is a 2D int matrix. I refer to this as the 
 * index matrix. It is so called because it stores integer values that represent the index in the image directory
 * that is stored in each specific coordinate in the matrix. This greatly reduces the memory cost of each individual
 * as I only need to store the fixed index of each image and then use that to represent my chromosome. Only when the actual
 * image is needed, do we use other functions to retrieve the image from the database and perform what operations are needed.
 * The images in the database do not change over time so fixed integer values are sufficient to represent them.
 * 
 * Finally, row and column variables are used to store the row and column sizes as specified by the user. This makes it easier
 * to construct the right sized chromosomes.
 */
public class Individual {

    
    /**
     * A getter method to retrieve the fitness score of the individual in question
     * 
     * @return 
     * Returns the specified fitness score associated with the individual in question
     */
    public double getFitnessScore() {
        
        return fitnessScore;
    }

    
    /** A setter method to set a fitness double that is the fitness of the 
     * individual in question
     * 
     * @param fitnessScore
     * The fitness value associated with the specific individual
     */
    public void setFitnessScore(double fitnessScore) {
        this.fitnessScore = fitnessScore;
    }
    
    int rows;
    int cols;
    double fitnessScore=0;
    int [][] chromosome;
    
    
    /**
     * Default Constructor
     */
    Individual()
    {
        
    }

    /**
     * A getter method to retrieve a specific chromosome stored by a specific
     * individual
     * @return chromosome
     * This returns the chromosome stored by the specific individual
     */
    public int[][] getChromosome() {
        return chromosome;
    }
    
    /**
     * This is an alternative constructor implementation used to create a new
     * individual instance with a pre-existing chromosome to be the individual's
     * chromosome
     */
    Individual(int a,int b,int[][] inChromo)
    {
        rows=a;
        cols=b;
        fitnessScore=0;
        chromosome=new int[a][b];
        
        for(int i=0;i<a;i++)
        {
            for(int j=0;j<b;j++)
            {
              chromosome[i][j]=inChromo[i][j];  
            }
        }
    }
    
    /**
     * Constructor method for Individual that takes number of rows and columns as 
     * arguments
     */
    Individual(int a,int b)
    {
        rows=a;
        cols=b;
        chromosome=new int[a][b];
        
    }
    /**
     * This is a setter function for the chromosome member of the Individual Class
     * @param chromosome
     * This is the target chromosome to set the individual's chromosome to
     * 
     * 
    */
    public void setChromosome(int[][] chromosome) {
        this.chromosome = chromosome;
        
    }
    
    /**
     * This is a setter method to set a specific gene in an individual at coordinates
     * x and y where x is row, and y is column
     * 
     * @param cellIndex
     * This is the index of the image from the database that is stored
     * 
     * @param x
     * This is the row value in the storage matrix chromosome 
     * 
     * @param y
     * This is the column value in the storage matrix chromosome 
    */
    
    public void setGene(int cellIndex, int x,int y)
    {
        
        chromosome[x][y]=cellIndex;
    }
}
