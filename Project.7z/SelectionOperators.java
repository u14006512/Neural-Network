/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Emilio Singh u14006512
 * 
 * The SelectionOperators class provides methods that perform the process of selection.
 * They select individuals based on their underlying method and will return selected individuals
 * back to the caller.
 * 
 * The reason for this implementation was to allow for easy of expansion of selection operations
 * The point of selection is to choose worthy individuals from the target population. The concept
 * of "worthy" depends wholly on the specific operator in question but each uses a different strategy to ensure that
 * an even number of parents are chosen from the presented population to be potential parents for a new
 * offspring generation. 
 * 
 * Operators Supported:
 * 1)Tournament Selection
 * 2)Roulette Wheel Selection
 */
public class SelectionOperators {

    int tournamentSize = 4;

    /**
     * Default Constructor
     */
    SelectionOperators() {

    }

    /**A getter for the size of tournaments
     * @return 
     * The size of tournaments for tournament selection.
     */
    public int getTournamentSize() {
        return tournamentSize;
    }

    /**A setter for the size of tournaments
     * @paramet
     * The size of tournaments for tournament selection to be set.
     */
    public void setTournamentSize(int tournamentSize) {
        this.tournamentSize = tournamentSize;
    }

    /**
     * This method implements Tournament Selection
     * It first constructs a list of all individuals to be competing for the chance
     * to be used in crossover.
     * 
     * After constructing the challenge pool, it determines the number of tournaments that 
     * have to take place.
     * 
     * This is simply the number of challengers/size of tournaments.
     * Something to note is that there may not always be a perfect amount of tournaments
     * in that not all tournaments may be comprised of full tournament rosters in that some
     * tournaments will have fewer than the allocated size of individuals competing.
     * This occurs when the tournament size does not perfectly divide into the 
     * size of the challenge pool. In this case, the tournament with fewer competitors
     * is referred to as the subRing as opposed to the general purpose theRing which is where
     * ordinary contests will occur.
     * 
     * Once the rings have been initialised, the process of selecting for them involves
     * randomly selecting individuals from the population to comprise a "ring", theRing or subRing being the actual
     * tournament.
     * 
     * Once this is done, the winner will be the individual with the highest fitness value.
     * This individual will be chosen for crossover and added to the winner list.
     * The other individuals, having lost, will not be returned to the challenge pool as proved weaker.
     * In this way, we ensure that we retrieve the best locally determined, that is local relative to their competitors,
     * solutions to be returned at the cost of some globally better solutions potentially losing out.
     * 
     * @param challengers 
     * The population of individuals from which individuals for crossover will be chosen
     * 
     * @param tourneySize 
     * The size of the tournaments to be used during Tournament Selection
     * @return 
     * The selected individuals chosen by Tournament Selection
     */
    public static ArrayList<Individual> tournamentSelectIndividuals(int tourneySize, Population challengers) throws IOException {

        System.out.println(" ");
        System.out.println("=============================");
        System.out.println("Tournament Selection Active");
        System.out.println("=============================");
        System.out.println(" ");
        ArrayList<Double> fitValues = new ArrayList<>();
        int poolNumbers = challengers.size / tourneySize;

        ArrayList<Individual> challengePool = new ArrayList<>();
        ArrayList<Individual> winners = new ArrayList<>();
        Individual[] theRing = new Individual[tourneySize];
        Individual[] subRing = null;
        challengePool.addAll(challengers.gaPop);

        while (poolNumbers >= 0 && challengePool.size()>0) {
            if (challengePool.size() > tourneySize) {
                Random number = new Random(System.nanoTime());

                int index;
                for (int i = 0; i < theRing.length; i++) {
                    theRing[i] = null;

                }
                int count = 0;
                int subIndex = 0;
                while (count != tourneySize) {
                    index = number.nextInt(challengePool.size());

                    if (theRing[subIndex] == null) {
                        theRing[subIndex] = new Individual(ImageManipulation.rows, ImageManipulation.cols, challengePool.get(index).getChromosome());
                        theRing[subIndex].fitnessScore = challengePool.remove(index).getFitnessScore();
                        count++;
                        subIndex++;
                    }
                }

            } else {
                subRing = new Individual[challengePool.size()];
                for (int i = 0; i < subRing.length; i++) {
                    subRing[i] = null;

                }
                for (int i = 0; i < subRing.length; i++) {
                    subRing[i] = new Individual(ImageManipulation.rows, ImageManipulation.cols, challengePool.get(i).getChromosome());
                    subRing[i].fitnessScore = challengePool.get(i).getFitnessScore();
                }
                challengePool.clear();
            }

            double maxFitness;
            int indexWinner = 0;
            if (theRing != null && theRing[0]!=null&& theRing.length > 0) {

                maxFitness = theRing[0].getFitnessScore();
                fitValues.clear();
                fitValues.add(maxFitness);
                for (int k = 1; k < theRing.length; k++) {
                    if (theRing[k].getFitnessScore() > maxFitness) {
                        indexWinner = k;
                        maxFitness = (theRing[k].getFitnessScore());
                        fitValues.add(maxFitness);
                    }
                }
                winners.add(theRing[indexWinner]);
            }

            if (subRing != null &&  subRing[0]!=null && subRing.length > 0) {
                indexWinner = 0;
                maxFitness = subRing[0].getFitnessScore();
                fitValues.clear();
                fitValues.add(maxFitness);
                for (int k = 1; k < subRing.length; k++) {
                    if (subRing[k].getFitnessScore() > maxFitness) {
                        indexWinner = k;
                        maxFitness = (subRing[k].getFitnessScore());
                        fitValues.add(maxFitness);
                    }
                }

                winners.add(subRing[indexWinner]);
                for (int i = 0; i < subRing.length; i++) {
                    subRing[i] = null;

                }

            }

            for (int i = 0; i < theRing.length; i++) {
                theRing[i] = null;

            }

            poolNumbers--;
        }

        if (winners.size() % 2 != 0) {
            int index = 0;
            double minFitness = winners.get(0).getFitnessScore();

            for (int k = 1; k < winners.size(); k++) {
                if (winners.get(k).getFitnessScore() < minFitness) {
                    index = k;
                    minFitness = winners.get(k).getFitnessScore();

                }
            }

            winners.remove(index);
        }

        return winners;
    }

    
    /**This method implements Roulette Wheel Selection.
     * 
     * It receives a population of individuals. Firstly, it will order the individuals by fitness 
     * in descending order.
     * 
     * Then it will determine the number of individuals to be selected.
     * This is taken as 50% of the input population that is then transformed to
     * the nearest even number should it not be even.
     * 
     * Once that is done, the process of selection begins with each "spin" of the
     * wheel equating to one member of the population being chosen for crossover.
     * Individuals that are chosen are not allowed to be chosen again and are removed
     * from the pool of "gamblers", that is individuals attempting to be selected for 
     * crossover.
     * 
     * Roulette Wheel Selection affords greater probability of being chosen based
     * on proportional fitness of an individual relative to the rest of the population.
     * By ordering the population by fitness from highest to lowest, and starting the wheel at 0,
     * we have the property that when choosing members, should we have the optimal fitness individual n
     * and fail to select this individual, we will select individuals after n whose fitness is worse than n, but better
     * than those further away from n. Roulette Wheel Selection has a typically high selective pressure so this is only
     * advisable when there are sufficient measures in place to offset the dominance of the "gene pool" by a handful
     * of individuals
     * 
     * @param gamblers 
     * The population from which individuals must be selected
     * 
     * @return 
     * The selected individuals chosen by Roulette Wheel Selection
     */
    public static ArrayList<Individual> rouletteWheelSelectIndividuals(Population gamblers) throws IOException {
        ArrayList<Individual> challengePool = new ArrayList<>();
        challengePool.addAll(gamblers.gaPop);
        ArrayList<Individual> winners = new ArrayList<>();
        Random sample = new Random(System.nanoTime());

        SortNode[] sortedListByFitness = new SortNode[challengePool.size()];
        for (int u = 0; u < challengePool.size(); u++) {
            sortedListByFitness[u] = new SortNode(challengePool.get(u), (challengePool.get(u).getFitnessScore()));
        }

        int i, j, first;
        SortNode temp;
        for (i = sortedListByFitness.length - 1; i > 0; i--) {
            first = 0;
            for (j = 1; j <= i; j++) {
                if (sortedListByFitness[j].getFitness() < sortedListByFitness[first].getFitness()) {
                    first = j;
                }
            }
            temp = sortedListByFitness[first];   //swap smallest found with element in position i.
            sortedListByFitness[first] = sortedListByFitness[i];
            sortedListByFitness[i] = temp;
        }

        challengePool.clear();

        for (int y = 0; y < sortedListByFitness.length; y++) {
            challengePool.add(sortedListByFitness[y].getIndie());
        }

        int spinsOfTheWheel = (int) (0.5 * challengePool.size());

        if (spinsOfTheWheel % 2 != 0) {
            spinsOfTheWheel = spinsOfTheWheel - 1;
        }

        while (spinsOfTheWheel > 0) {
            int n = 0;
            double sum = calcSlice(challengePool, 0);
            double limit = sample.nextDouble();

            while (sum < limit) {
                n++;
                sum += calcSlice(challengePool, n);
            }
            if (winners.contains(challengePool.get(n)) == false) {
                winners.add(challengePool.remove(n));
                spinsOfTheWheel--;
            }

        }

        return winners;
    }
    
    /**
     * This is a helper function that calculates what percentage of the total fitness
     * in the population, the input image has 
     * 
     * @return 
     * The percentage proportion the input image at index has in the total population fitness
     * 
     * @param gamblers 
     * The input list of members of the population eligible for selection
     * 
     * @param index
     * The specific member in the list, at the index, whose proportionate fitness relative
     * to the population needs to be calculated.
     */
    static private double calcSlice(ArrayList<Individual> gamblers, int index) throws IOException {
        double fitTotal = 0;

        for (int i = 0; i < gamblers.size(); i++) {
            fitTotal = fitTotal + gamblers.get(i).getFitnessScore();
        }
        return gamblers.get(index).getFitnessScore() / fitTotal;
    }
}