#!/bin/bash
javac ./*.java
