/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;

/**
 *
 * @author Emilio Singh u14006512
 * 
 * ImageManipulation is a class that provides a very important set of functions that 
 * directly relate to the handling of images in the program.
 * 
 * Although, by and large, the use of index matrices has limited the use of images,
 * and indeed, memory and efficiency concerns have meant that image use must be done sparingly,
 * a final mosaic must be constructed as a jpg meaning that images will have to be used and manipulated
 * at some point.
 * 
 * This class provides a suite of functions that:
 * 1) Enable images to be retrieved from the directory
 * 2) Scale images as needed to sizes
 * 3) Generate random indexes of images from the image directory
 * 4) Calculates the appropriate sizes of the final image as well as several secondary values
 * 5) Creates the final image by using graphics processing to "stitch" the images represented by
 *    an image matrix into actual images that comprise a jpg.
 */
public class ImageManipulation {

    

    /**A getter method to get the index value of the source image to be made
     * @return 
     * The index in the image directory of the source image.
     */
    public static  int getSrcImageIndex() {
        return srcImageIndex;
    }
    static int actWidth;

    /**A getter method to get the actual width value for the final image 
     * @return 
     * The width of the final image 
     */
    public static int getActWidth() {
        return actWidth;
    }

    public static void setActWidth(int actWidth) {
        ImageManipulation.actWidth = actWidth;
    }

    /**A getter method to get the actual height value for the final image 
     * @return 
     * The height of the final image 
     */
    public static int getActHeight() {
        return actHeight;
    }

    
    public static void setActHeight(int actHeight) {
        ImageManipulation.actHeight = actHeight;
    }
    static int actHeight;
    static int tileSize;
    static int srcImageIndex;
    static String dir;
    static int type;
    static int rows;
    static int cols;
    static int sourceHeight;
    static int sourceWidth;
    
    /**
     * Default Constructor
     */
    public ImageManipulation() {
    }

    /**
     * Constructor method to set up row/column values used in image processing
     */
    ImageManipulation(int x, int y) {
        rows = x;
        cols = y;
    }

    /**A getter method to get the row value for the image tile map
     * @return 
     * The row value that was stored for image processing
     */
    public static int getRows() {
        return rows;
    }

    /**A setter method to set the row value for the image tile map
     * @param rows
     * The row value to be stored for image processing
     */
    public static void setRows(int rows) {
        ImageManipulation.rows = rows;
    }
    
    /**A getter method to get the column value for the image tile map
     * @return 
     * The column value that was stored for image processing
     */
    public static int getCols() {
        return cols;
    }

    /**A setter method to set the column value for the image tile map
     * @param cols
     * The column value to be stored for image processing
     */
    public static void setCols(int cols) {
        ImageManipulation.cols = cols;
    }

    
    /**This method receives the source directory for the images as well as the 
     * target image to evolve.
     * 
     * It will search through the image directory until it finds the target image
     * and it will store some necessary information about this target image
     * 1) Index in directory where the image can be found
     * 2) Its height and width
     * 
     * Then it will calculate two values: actualHeight and actualWidth which will
     * be set later in the function.
     * 
     * These values,represent the height and width of the final image to be made.
     * It is important to calculate these values to ensure that the necessary image scaling is 
     * done such that the number of rows and columns align perfectly to overlay the image tiles
     * onto the final image mosaic.
     * 
     * However, height and width must be integer values and not doubles or floats as they
     * are a specified number of pixels.
     * 
     * To accommodate this, a process must be followed to derive the actual height and width
     * values. The process is outlined below.
     * 
     * 1) Height mod rows= amount of pixel overflow in terms of rows
     * 2) Width mod cols=amount of pixel overflow in terms of columns
     * 
     * If both of the values are 0, then our row count and column count are such
     * that we can equally divide the respective row and column count into height and width
     * such that we form tiles.
     * 
     * However, in the likelier case that this is not true, we need to perform a scaling operation
     * to adjust the height and width such that we get the nearest values to their originals
     * such that we can perfectly divide the column and row values into them.
     * 
     * height,width refer to the height and width of the target image.
     * 
     * If (height % rows &lt rows/2) actualHeight=(height-(height % rows));
     * If (height % rows &gt= rows/2) actualHeight=height+(rows-(height % rows));
     * 
     * If (width% cols &lt cols/2) actualWidth=(width-(width % cols));
     * If (width % cols &gt= cols/2) actualWidth=width+(cols-(width% cols));
     * 
     * In the above cases, we will either transform height and width such that,
     * If the height value is closer than the closest multiple of rows or cols that is less than itself respectively
     * we will reduce it to that value.
     * 
     * In the even that the height/width is closer to a higher value that is a multiple of cols/rows, we increase it to that value
     * 
     * Lastly, we perform a calculation of the tile size which is defined roughly as 
     * tileWidth=getActWidth()/ImageManipulation.getCols() 
     * tileHeight=getActHeight()/ImageManipulation.getRows() 
     * 
     * This is merely an approximation of the tile size. 
     * @param baseImage 
     * The name of the jpg image that the GA will try to evolve
     * @param folder 
     * The name of the image directory where all of the images are kept
     */
    public void preprocessImages(String folder, String baseImage) throws IOException {

        dir = folder;
        int x = 0, y = 0;

        File directory = new File(folder);
        File[] contents = directory.listFiles();
        
        for (int i = 0; i < contents.length; i++) {
            String s=contents[i].getName();
            if (s.equals(baseImage)) {
                srcImageIndex = i;
                BufferedImage tmpImg=ImageIO.read(contents[i]);
                //Width==number of columns
                //Height==number of rows
                y = tmpImg.getWidth();
                sourceWidth=y;
                x = tmpImg.getHeight();
                sourceHeight=x;
                type=tmpImg.getType();
                
                int actualHeight = 0;
                int actualWidth = 0;
                tmpImg=ImageIO.read(contents[srcImageIndex]);
                
                //Height
                if (tmpImg.getHeight()% ImageManipulation.getRows()==0)
                {
                    actualHeight=tmpImg.getHeight();
                }
                
                if (tmpImg.getHeight()% ImageManipulation.getRows()<(Math.floor(ImageManipulation.getRows()/2)))
                {
                    actualHeight=tmpImg.getHeight()-((tmpImg.getHeight()%ImageManipulation.getRows()));
                }
                if (tmpImg.getHeight()% ImageManipulation.getRows()>=(Math.floor(ImageManipulation.getRows()/2)))
                {
                    actualHeight=tmpImg.getHeight()+(ImageManipulation.getRows()-((tmpImg.getHeight()%ImageManipulation.getRows())));
                }
                
                //
                //Width
                if (tmpImg.getWidth()% ImageManipulation.getCols()==0)
                {
                    actualWidth=tmpImg.getWidth();
                }
                
                if (tmpImg.getWidth()% ImageManipulation.getCols()<(Math.floor(ImageManipulation.getCols()/2)))
                {
                    actualWidth=tmpImg.getWidth()-((tmpImg.getWidth()%ImageManipulation.getCols()));
                }
                if (tmpImg.getWidth()%ImageManipulation.getCols()>=(Math.floor(ImageManipulation.getCols()/2)))
                {
                    actualWidth=tmpImg.getWidth()+(ImageManipulation.getCols()-((tmpImg.getWidth()%ImageManipulation.getCols())));
                }
                setActHeight(actualHeight);
                setActWidth(actualWidth);
            }
     
        }

    }

    /**This method will generate an index value representing an image from the image
     * directory, with the exception of the source image, and return this index.
     * @return 
     * This returns an index of an image chosen at random from the image directory.
     */
    public static int genIndex() {
        File directory = new File(dir);
        File[] contents = directory.listFiles();

        Random getF = new Random(System.nanoTime());

        int index = getF.nextInt(contents.length);
        if (index==srcImageIndex) index = getF.nextInt(contents.length);
        return index;
    }

    /**This method receives an index value and returns the image associated with
     * the index from the image directory.
     * 
     * @param index 
     * The index value of where to find the image in the image directory.
     * @return 
     * This returns the actual image, represented as a BufferedImage type,
     * that is found in the image directory at the given index
     */
    public static BufferedImage getImage(int index) throws IOException {

        File directory = new File(dir);
        File[] contents = directory.listFiles();
        BufferedImage tmp;
        
        if (index!=srcImageIndex){
        tmp = Scalr.resize(ImageIO.read(contents[index])
                ,Scalr.Method.SPEED
                ,Scalr.Mode.FIT_EXACT
                , getActWidth()/ImageManipulation.getCols()
                ,getActHeight()/ImageManipulation.getRows());
        
        }
        else 
            {
                
                
                tmp=Scalr.resize(ImageIO.read(contents[srcImageIndex]),Scalr.Mode.FIT_EXACT,getActWidth(),getActHeight());
            }
        
        return tmp;
    }

    /**
     * * This method takes the chromosome of the finalChoice individual and then converts it
     * into BufferedImage type images which are then added, tile by tile, to a final image BufferedImage
     * which is then written to the directory as jpg with the user specified name.
     * 
     * Much of the work of performing the graphics handling is offloaded to the inherent 
     * capacities of the BufferedImage class.
     * 
     * To ensure that images fit, the Scalr class, an external class that provides image
     * manipulation functions, performs an exact-size resize of images taken from the directory
     * to ensure they fit into the tiles specified by the rows and columns values.
     
     * @param  finalChoice
     * This is the individual representing the individual from the population with the highest
     * fitness value of all individuals in the population.
     * 
     */
    public static void generateFinalImage(Individual finalChoice) throws IOException {

        int rows = finalChoice.rows;
        int cols = finalChoice.cols;
        int numTiles = rows * cols;

        int tileWidth, tileHeight;
        
        
        BufferedImage finalImg = new BufferedImage(getActWidth(), getActHeight(),ImageManipulation.type);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                finalImg.createGraphics().drawImage(Scalr.resize(getImage(finalChoice.chromosome[i][j]),
                        Scalr.Mode.FIT_EXACT,
                        (int)getActWidth()/Population.getCols(),
                        (int)getActHeight()/Population.getRows()),
                        (int)getActWidth()/Population.getCols()*j,
                        (int)getActHeight()/Population.getRows()*i,null);
            }
        }

        System.out.println("");
        System.out.println("==============================");
        System.out.println("Target Image created");
        System.out.println("Target Image Fitness:"+fitnessFunction.getFitness(finalChoice));
        System.out.println("==============================");
        System.out.println("");
        ImageIO.write(finalImg, "jpg", new File(GeneticAlgorithm.getTargetName() + "_mosaic.jpg"));
    }

}
