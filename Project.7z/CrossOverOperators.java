/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates

 * and open the template in the editor.
 */

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Emilio Singh u14006512
 * 
 * The CrossOverOperators class provides a single crossover method that will make
 * use of an underlying method to generate crossover masks. This method allows us
 * to easily add new crossover operators without fundamentally changing the process
 * of crossover.
 * 
 * 
 * 
 * Operators Supported:
 * 1)Uniform Crossover
 * 2)2 Point Crossover
 */
public class CrossOverOperators {

    /**
     * Default Constructor
     */
    public CrossOverOperators() {
    }

    
    /**This method implements the crossover process. Two parents are received as 
     * input parameters along with a crossover type and probability. 
     * There is a mapping of a 2D array to a 1D array in terms of mapping
     * the 2D chromosome to 1D representation array. What happens is that the 2D
     * array is essentially "stretched out", that is transformed, into a single 1D
     * array containing all of the elements from the 2D array in order.
     * 
     * This is done to facilitate a simpler representation for the crossover mask later on.
     * 
     * The method then generates the appropriate mask that corresponds to the crossover type
     * selected and gets a random double value. If this value is less than or equal to the chance of crossover,
     * a crossover occurs and two new children will be generated using the mask to facilitate which
     * of the genes of which of the parents will be used to generate genes for the children. 
     * 
     * Otherwise, no crossover will occur and an empty array will be returned.
     * 
     * 
     * @param probability 
     * The probability of a crossover occurring between the two parents
     * 
     * @param crossOverType 
     * The type of crossover operator to be used during crossover 
     * 
     * @param parent1 
     * The first of the two parents chosen for crossover
     * 
     * @param parent2 
     * The second parent chosen for crossover
     * @return 
     * This method returns a list of all the children, two, created by crossover between the input 
     * parents
     */
    public static ArrayList<Individual> crossOver(double probability, Individual parent1,
            Individual parent2, int crossOverType) {

        Random chance = new Random(System.nanoTime());
        
        ArrayList<Individual> children=new ArrayList<>();
        
        Individual child1 = new Individual(parent1.rows, parent1.cols);
        Individual child2 = new Individual(parent2.rows, parent2.cols);

        double crossOverRoll = chance.nextDouble();

        if (crossOverRoll <= probability) {
            int[] mask = generateMask(crossOverType, parent1.rows * parent1.cols, GeneticAlgorithm.getCrossPX());

            int[] childChromo1 = new int[parent1.rows * parent1.cols];

            int[] childChromo2 = new int[parent2.rows * parent2.cols];

            int[] tmpParent1GeneList = new int[parent1.rows * parent1.cols];
            int[] tmpParent2GeneList = new int[parent1.rows * parent1.cols];

            int k = 0;
            int h = 0;
            for (int i = 0; i < parent1.rows; i++) {
                for (int j = 0; j < parent1.cols; j++) {
                    tmpParent1GeneList[k] = parent1.chromosome[i][j];
                    tmpParent2GeneList[h] = parent2.chromosome[i][j];
                    k++;
                    h++;
                }
            }

            for (int i = 0; i < mask.length; i++) {
                if (mask[i] == 1) {
                    childChromo1[i] = tmpParent2GeneList[i];
                    childChromo2[i] = tmpParent1GeneList[i];
                } else {
                    childChromo1[i] = tmpParent1GeneList[i];
                    childChromo2[i] = tmpParent2GeneList[i];
                }
            }

            int[][] tmpChromo = new int[parent1.rows][parent1.cols];
            int[][] tmpChromo2 = new int[parent1.rows][parent1.cols];

            int r = 0;
            for (int i = 0; i < parent1.rows; i++) {
                for (int j = 0; j < parent1.cols; j++) {
                    tmpChromo[i][j] = childChromo1[r];
                    tmpChromo2[i][j] = childChromo2[r];
                    r++;
                }
            }

            child1.setChromosome(tmpChromo);
            child2.setChromosome(tmpChromo2);
            children.add(new Individual(child1.rows,child1.cols,child1.chromosome.clone()));
            children.add(new Individual(child2.rows,child2.cols,child2.chromosome.clone()));
            
        }
        return children;
    }

    /**
     * To facilitate a crossover method, we require a mask that indicates which of
     * the images in the parents are to be swapped with their corresponding images in the 
     * corresponding parent to generate the final cell/gene value for the children.
     * 
     * This method generates a linear array that contains integer values that will be used
     * to determine which of the parents' genes, for which of the children, are used when 
     * constructing the children.
     * 
     * @return 
     * This will return a linear array representing the crossover mask
     * @param probability 
     * The probability that a given cell in a chromosome will result in the mask being a
     * 1, indicating a crossover
     * @param size 
     * The size of the chromosome, as represented by a 1D array
     * @param type 
     * The type of mask needed to be made based on the various methods
     * 1: Uniform crossover
     * 2: 2 point crossover
     */
    private static int[] generateMask(int type, int size, double probability) {
        int[] mask = new int[size];

        for (int i = 0; i < mask.length; i++) {
            mask[i] = 0;
        }

        switch (type) {
            //Uniform Cross Over
            case 1:
                double px = probability;

                Random chance = new Random(System.nanoTime());
                double roll;
                for (int i = 0; i < size; i++) {
                    roll = chance.nextDouble();

                    if (roll <= px) {
                        mask[i] = 1;
                    } else {
                        mask[i] = 0;
                    }
                }

                break;

            //2 Point Cross Over    
            case 2:
                Random chance2 = new Random(System.nanoTime());

                int indexLower,
                 indexUpper,
                 i1,
                 i2;

                i1 = chance2.nextInt(size);
                i2 = chance2.nextInt(size);

                if (i1 > i2) {
                    indexUpper = i1;
                    indexLower = i2;
                } else {
                    indexUpper = i2;
                    indexLower = i1;
                }

                for (int i = indexLower; i <= indexUpper; i++) {
                    mask[i] = 1;
                }

                break;
        }

        return mask;
    }
}
