/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author Emilio Singh u14006512
 * 
 * The MutationOperators class contains all of the methods necessary to 
 * perform mutation on individuals in the population.
 * 
 * The class contains various functions that are used to sample values to add 
 * variability to the nature of mutation as well as a filtering method, discussed 
 * below, that helps to improve the efficiency of the mutation process.
 * 
 */
public class MutationOperators {

    /**
     * Default Constructor
     */
    MutationOperators() {

    }

    /**
     * The mutation that operates here follows the initial constraints as were
     * defined in that no adjacency of any kind is allowed when generating
     * images and mapping them to cells, with a further requirement of a 20%
     * maximum image prevalence in a given chromosome.
     *
     * However, to further increase the efficiency of the mutation process, we
     * apply a minimum Gain Threshold value requirement. What this does is
     * mandate that for a new image to be incorporated into an individual's
     * chromosome, it must enable an increase in the fitness of the individual
     * by some minimum value, that is,
     *
     * (|fitnessBeforeMutation-fitnessAfterMutation|>thresHoldValue)
     *
     * This will however accept the first cell to conform to the abovementioned
     * criteria but it will still selectively filter out weaker cells that would
     * have otherwise not contributed meaningfully towards fitness.
     *
     * Furthermore, note that the thresHoldValue is sampled from a transformed
     * quadratic equation and will initially start at 0, at generation 0, before
     * growing at a reasonable curve as generations goes up.
     *
     * The value will greatly increase if generations is a large number and be a
     * smaller number while generations is a small number. This means that once
     * we have had many generations, a cell will have to then be exceedingly
     * meaningful to be accepted. This however, is only provided a large
     * generation capacity is used. For smaller values, it still provides a
     * meaningful filter without mandating a gigantic image directory be used.
     *
     * @param generation The current generation number
     *
     * @return A double value indicating the minimum increasing in fitness
     * required for a newly mutated cell to be accepted into a chromosome.
     */
    public static double getGainThresholdValue(int generation) {
        return Math.sqrt(generation);
    }

    /**
     * Once it has been determined that a given individual will mutate, we then
     * need to determine how many of the cells in the individual will mutate.
     *
     * We have a fixed mutation rate per individual, so at any moment, all
     * individuals will have the same, static chance of being eligible for
     * mutation.
     *
     * However, the degree to which they mutate is not fixed but rather
     * determined by sampling a value from a sigmoidal function that has been
     * altered to create a curve such that for the function F(x) with x=0,
     * F(x)=1 is approximately 1.
     *
     * The function, has been transformed into: y(x)=5/(1+e^(sqrt(x+2)))
     *
     * The effect of this transformation is that gradual sloped descent for the
     * chance of mutation from approximately 1 to approximately 0.15 by
     * generation 10. This provides a good initial mutation rate which will slow
     * down as the generations wear on and mutation becomes more likely to
     * mutate good solutions than to mutate bad solutions towards better states.
     * While note quite exponential in nature, the curve does enable a sizable
     * difference in mutation rates at the beginning of the process versus
     * mutation rates after, even 20, generations. Further experimental research
     * will have to be conducted to determine the true utility of this
     * transformation but for current purposes, it serves well.
     *
     * @param generation The current generation number
     *
     * @return A double value representing the probability of a single cell
     * mutating
     */
    public static double getMutationPm(int generation) {
        return 5 / (1 + (Math.pow(Math.E, Math.sqrt(generation + 2))));
    }

    /**This method will perform mutation of genes of the individual that it receives.
     * It will first determine the current gene mutation rate as given by the function:
     * y(x)=5/(1+e^(sqrt(x+2))) where x is the current generation of the individual.
     * 
     * After this, it will use that probability to construct a mutation matrix for the individual.
     * 
     * Then, it will for each gene in the individual, determine if that gene/cell mutates
     * and if so, what the effect of that will be.
     * 
     * 
     * @return This returns the individual received, with mutations applied if
     * application
     *
     * @param candidate
     * The individual in question that must now be mutated in terms of each
     * of their cells mutating, potentially.
     * 
     * If it is the case that a cell/gene/image will be mutated, it does not simply
     * draw a random image from the database, or its index. Rather, it imposes a set 
     * of filters on cells drawn from the image directory in terms of imposing conditions that
     * an image must meet before being integrated into the individual's chromosome.
     * 
     * These conditions are as follows:
     * 1) The new mutated image must not have any adjacent images in its location.
     * 2) The new mutated image must not already be more than 20% of the chromosome's composition
     * 3) The new mutated image must result in a positive increase of the individual's fitness by some minimum threshold value determined by 
     * function H(x)=sqrt(x);
     * 
     * If the mutated image does not meet all of these criteria, a new image will be drawn from the 
     * directory until one does.
     * 
     * Although it imposes a sizable performance bonus, there are a number of factors to consider that are positive.
     * The first is that the method will accept the first image that meets these criteria.
     * For a sufficiently large image directory, this will be ideal as more images increases
     * the likelihood of an image in meeting those criteria.
     * 
     * Secondly, the filters block cells that do not contribute to the fitness of 
     * the individual. However, it is not so strict that it would deny a sizable chunk
     * of the image population the right to be integrated with the individual. Rather, as the required
     * gain threshold increases, the value of the image in contributing to the image increases as well which prevents 
     * good solutions from being mutated to worse ones and potentially allows for bad solutions to be
     * kickstarted into better positions by finding much better images than those 
     * currently in their chromosomes.
     * @param type
     * The type of mutation operator to be used.
     */
    public static Individual mutateIndividual(Individual candidate, int type) throws IOException {

        System.out.println(" ");
        System.out.println("=============================");
        System.out.println("Mutation Starting");
        System.out.println("=============================");
        System.out.println(" ");
        Random chance = new Random(System.nanoTime());
        double currMutProb = getMutationPm(GeneticAlgorithm.getGenerations());
        double probRoll;

        int[][] tmpChromosome = new int[candidate.rows][candidate.cols];

        for (int i = 0; i < candidate.rows; i++) {
            for (int j = 0; j < candidate.cols; j++) {
                tmpChromosome[i][j] = candidate.chromosome[i][j];
            }
        }

        int[][] mutationMatrix = getMutationMatrix(type, candidate, currMutProb);

        Individual mutatedIndi = new Individual(candidate.rows, candidate.cols, tmpChromosome);

        double priorFitness, currentFitness;

        for (int i = 0; i < candidate.rows; i++) {
            for (int j = 0; j < candidate.cols; j++) {
                if (mutationMatrix[i][j] == 1) {
                    System.out.println(" ");
                    System.out.println("=============================");
                    System.out.println("Mutating Cell: [" + i + ":" + j + "]");
                    System.out.println("=============================");
                    System.out.println(" ");
                    //mutate cell

                    boolean acceptableGain = false;

                    do {
                        int index = ImageManipulation.genIndex();
                        if (index == ImageManipulation.srcImageIndex) {
                            index = ImageManipulation.genIndex();
                        }

                        priorFitness = mutatedIndi.getFitnessScore();
                        int newImage = index;

                        tmpChromosome[i][j] = newImage;

                        currentFitness = fitnessFunction.getFitnessChromosome(tmpChromosome);

                        //
                        if (Population.checkValidity(candidate) == true && currentFitness > priorFitness && ((currentFitness - priorFitness)) > getGainThresholdValue(GeneticAlgorithm.getGenerations())) {
                            acceptableGain = true;
                        }
                    } while (acceptableGain == false);
                }
            }
        }

        return mutatedIndi;
    }

    /**
     * Much like with crossover, mutation is handled by constructing a matrix
     * where 1 indicates a cell will mutate and 0, not. This matrix however is a
     * 2D matrix and not a 1D matrix as with crossover.
     *
     * The method will construct the matrix based on the candidate individual
     * and then, for each cell, sample a value from a uniform distribution
     * between 1 and 0 and if the sample, U, is less than or equal to the
     * mutRate, that cell will mutate
     *
     * Also note that the Inorder Mutation works in the following way: It will
     * randomly determine two values from 0 to RowCount. All of the cells,
     * column-wise, between the two rows will then be eligible for a chance to
     * mutate.
     *
     * This dramatically increases the region of cells that are potentially
     * mutating in comparison to the Random distribution method which randomly
     * determines if all cells have a chance to mutate.
     *
     *
     * @param candidate The individual for whom the mutation matrix must be
     * generated
     *
     * @param mutRate The probability that a given cell x will mutate
     *
     * @param type The type of mutation operator used
     */
    public static int[][] getMutationMatrix(int type, Individual candidate, double mutRate) {
        Random chance = new Random(System.nanoTime());
        double roll;

        int[][] matrix = new int[candidate.rows][candidate.cols];

        switch (type) {
            //Random
            case 1:
                for (int i = 0; i < candidate.rows; i++) {
                    for (int j = 0; j < candidate.cols; j++) {
                        roll = chance.nextDouble();

                        if (roll <= mutRate) {
                            matrix[i][j] = 1;
                        } else {
                            matrix[i][j] = 0;
                        }
                    }
                }

                break;

            //In Order    
            case 2:

                Random chance2 = new Random(System.nanoTime());

                int indexLower,
                 indexUpper,
                 i1,
                 i2;

                i1 = chance2.nextInt(candidate.rows);
                i2 = chance2.nextInt(candidate.rows);

                if (i1 > i2) {
                    indexUpper = i1;
                    indexLower = i2;
                } else {
                    indexUpper = i2;
                    indexLower = i1;
                }
                Random r = new Random(System.nanoTime());
                double tr;
                for (int i = indexLower; i <= indexUpper; i++) {
                    for (int j = 0; j < candidate.cols; j++) {
                        if ((tr = r.nextDouble()) <= mutRate) {
                            matrix[i][j] = 1;
                        }

                    }
                }

                break;
        }

        return matrix;
    }
}
